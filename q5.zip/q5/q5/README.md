Before running the code open up app.py and replace 

```
PROJECT_NUMBER = 'xxxxxxxxxxx'
```
with your project number.
