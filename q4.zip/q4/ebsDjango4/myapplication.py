import os
import sys


def main():
	print "In main"

if __name__ == "__main__":
	main()

