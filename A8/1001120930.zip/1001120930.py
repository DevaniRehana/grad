# -*- coding: utf-8 -*-
"""
Created on Mon Jul 06 18:25:29 2015

@author: Harish_kamuju
"""


import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
import sklearn
from sklearn.cluster import KMeans
#from nltk.corpus import stopwords
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
#from itertools import cycle
import numpy as np
import sys

#stopwrdslist = stopwords.words('english')

def main(option):
    try:
        clusters = int(raw_input('Enter the number of clusters:'))
    except:
        print 'Invalid Cluster Number'
        return
    df = pd.read_csv('Consumer2.csv',skiprows=[0],header=None)#, delim_whitespace=True)
    #state = df[23],City = df[22]
    #product category = df[6]
    #product subcat = df[7]
    #product type = df[8]
    #brand = df[11] 
    if option == 1:
        temp = pd.get_dummies(df[23])   
    elif option == 2:
        temp = pd.get_dummies(df[22])
    elif option == 3:
        temp = pd.get_dummies(df[6])
    elif option == 4:
        temp = pd.get_dummies(df[7])
    elif option == 5:
        temp = pd.get_dummies(df[8])
    elif option == 6:
        temp = pd.get_dummies(df[11])
    
    mat = temp.as_matrix()
    km = sklearn.cluster.KMeans(n_clusters=clusters)
    km.fit(mat)
    labels = km.labels_
    results = pd.DataFrame([temp.index,labels]).T
    if option == 1:
        results['States'] = df[23]
    elif option == 2:
        results['City'] = df[22]
    elif option == 3:
        results['Product Category'] = df[6]
    elif option == 4:
        results['Product SubCat'] = df[7]
    elif option == 5:
        results['Product Type'] = df[8]
    elif option == 6:
        results['Brand'] = df[11]
        
    print "Clusters :"
    print results
    reduced_data = km.cluster_centers_
    print "Cluster Centers:"
    print reduced_data
    centroids = PCA(n_components=2).fit_transform(reduced_data)
    
    plt.scatter(centroids[:, 0], centroids[:, 1],
            marker='o', s=160, linewidths=2,
            color='b', zorder=1)
    plt.show()
    
    

if __name__ == "__main__":
    while True:
        print "Select from the list to Cluster:"
        try:
            option = int(raw_input('''1.State\n2.City\n3.Product Category\n4.Product SubCategory\n5.Product Type\n6.Brand\n7.Exit\nInput:'''))
        except:
            print 'Invalid Option. Exiting!'
            break
        if option in range(1,7):
            main(option)
            break
        else:
            print 'Exiting!!!'
            break
    #sys.exit(0)
            
        
